"""
Tencent Weibo API for Python
"""
__version__ = '1.0'

from oauth import OAuth2Handler
from tweibo import API
